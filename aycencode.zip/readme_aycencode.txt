﻿----------------
互換SHIORIコア「文」暗号化辞書作成プログラム
----------------

使い方は起動すればわかります。

20020310
version 1.0
  for 文 version 2.0 or later

author : umeici

:::et cetera.
http://members.jcom.home.ne.jp/umeici/
E-mail:umeici@jcom.home.ne.jp
