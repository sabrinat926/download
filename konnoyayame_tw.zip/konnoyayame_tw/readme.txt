﻿----------------
「YAYA」テンプレートゴースト
紺野ややめ
----------------

20070227
YAYA version Tc524-5

20071021
Chinese version 1.02

original author : umeici
change by : ukiya
中文化 by : 時原砂
